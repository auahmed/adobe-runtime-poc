module.exports = {
  audienceId: "1821808",
  tenant: "aknbusinessolamerptrsd",
  credentials: {
      clientId : "765b6965229a4f83a2aa70883eaefce7", //Application ID (Client ID)
      technicalAccountId : "EA81194560BF71260A495E5D@techacct.adobe.com", //Technical account ID
      orgId : "ECE34E785E54ED240A495C13@AdobeOrg", // Org ID
      clientSecret : "p8e-fQvm97WMnFwNiSgJI0jRUryUXj4GZpya", //Client Secret
      metaScopes : "ent_marketing_sdk", // Metascopes
      privateKey : "-----BEGIN PRIVATE KEY-----\n" +
      "MIIEvwIBADANBgkqhkiG9w0BAQEFAASCBKkwggSlAgEAAoIBAQDiQZr7Bl5XUT5mD22cuKR+Ai3/\n" +
      "-----END PRIVATE KEY-----\n"
  }
}
